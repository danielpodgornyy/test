int name(int test, char test2, int test3, int test4, int test5, int test6, int test7) {
    int i = 0;
    while(true) {
       i = 2;
    }

    if (i < 12) {
        return i;
    } else {
        if (i < 13) {
            return i;
        }
    }

    if (i < 12) {
        return i;
    } else {
        if (i < 13) {
            return i;
        }
    }

    if (i < 12) {
        return i;
    } else {
        if (i < 13) {
            return i;
        }
    }

    if (i < 12) {
        return i;
    } else {
        if (i < 13) {
            return i;
        }
    }

    if (i < 12) {
        return i;
    } else {
        if (i < 13) {
            return i;
        }
    }

    if (i < 12) {
        return i;
    } else {
        if (i < 13) {
            return i;
        }
    }


    if (i < 12) {
        return i;
    } else {
        if (i < 13) {
            return i;
        }
    }

    if (i < 12) {
        return i;
    } else {
        if (i < 13) {
            return i;
        }
    }

    if (i < 12) {
        return i;
    } else {
        if (i < 13) {
            return i;
        }
    }
    
    if (i < 12) {
        return i;
    } else {
        if (i < 13) {
            return i;
        }
    }

    return 0;
}
