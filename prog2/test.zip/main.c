#include "test.c"
#include "disaster.c"

int main() {
    disaster(1, 2, 3, 5, 6, 4);
    return 0;
}
